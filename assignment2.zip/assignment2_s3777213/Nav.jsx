import React,{Component}   from 'react'
import {BrowserRouter as Router, Link, Route, Switch} from 'react-router-dom'
import Edit from './Edit.jsx'
import Category from './Category.jsx';
import Homepage from './Homepage.jsx';
import EditProduct from './EditProduct.jsx'
import Grid from './List.jsx';
function searchingFor(term){
  return function (x) {
    return x.email.toLowerCase().includes(term.toLowerCase()) || false;
  }
}

export default class Nav extends React.Component {
  constructor(props){
    super(props);
    this.state = {
        students: [],
        term : "",
        price:"",
        name:"",
        id:""
    }
    this.searchHandeler= this.searchHandeler.bind(this);
}

searchHandeler(event){
this.setState({ term: event.target.value})
console.log(event.target.value);
}

fetchData(){
  var url = 'https://reqres.in/api/users'
  fetch(url)
      .then(res=>res.json())
      .then(json=>this.setState({students: json.data}))
}

componentWillMount(){
  this.fetchData()
}


 
   
   render() {
     const{term, students} = this.state;
       return (
        <Router>

         <div className="App">
        <nav className="navbar navbar-expand-lg navbar-light bg-light">
        <Link to="/" className="navbar-brand" href="/">T-Market</Link>
        <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span className="navbar-toggler-icon"></span>
        </button>

        <div className="collapse navbar-collapse" id="navbarSupportedContent">
          <ul className="navbar-nav mr-auto">
            <li className="nav-item active">
              <Link className="nav-link" to={'/'}>Home </Link>
            </li>
            <li className="nav-item">
              <Link to={'/category'} className="nav-link" >Product Category</Link>
            </li>
            <li className="nav-item">
              <Link to={'/editproduct'} className="nav-link" >Edit Products</Link>
            </li>
            <li className="nav-item">
              <Link to={'/edit'} className="nav-link disabled" href="/"></Link>
            </li>
          </ul>
          <form className="form-inline my-2 my-lg-0">
            <input className="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search" />
            <button className="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
          </form>
        </div>
      </nav>
      <Switch>
      <Route exact path="/" component={Homepage}></Route>

        <Route path="/category" component={Category}></Route>
        <Route path="/editproduct" component={EditProduct}></Route>
        <Route path="/edit" component={Edit}></Route>

      </Switch>
      
  
 

      </div>
      </Router>

       )
   }
 
}
