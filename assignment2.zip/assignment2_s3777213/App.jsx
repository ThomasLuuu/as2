import React,{Component} from 'react'
import {BrowserRouter as Router} from 'react-router-dom'
import Hello from './Hello.jsx'
 import Navigation from './components/Navigation.jsx'
 import Edit from './Edit.jsx'
 import Category from './Category.jsx'
 import Nav from './Nav.jsx'
 import Products from './Products.jsx'
 
import Homepage from './Homepage.jsx'
export default class App extends React.Component{
    render(){
        return( 
            <div>
                <div>
                    <Nav/>
            
                </div>
                
        </div>
        )
    }
}