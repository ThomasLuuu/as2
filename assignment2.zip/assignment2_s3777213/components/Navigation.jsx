import React from 'react'

class Navigation extends React.Component{
    render(){
        return(
            <div>Navigation</div>
        )
    }
}