import React,{Component}   from 'react'
import {BrowserRouter as Router, Link, Route, Switch} from 'react-router-dom'
import Edit from './Edit.jsx'
import Category from './Category.jsx';

import Grid from './List.jsx';
function searchingFor(term){
  return function (x) {
    return x.email.toLowerCase().includes(term.toLowerCase()) || false;
  }
}

export default class Homepage extends React.Component {
  constructor(props){
    super(props);
    this.state = {
        students: [],
        term : "",
        price:"",
        name:"",
        id:""
    }
    this.searchHandeler= this.searchHandeler.bind(this);
}

searchHandeler(event){
this.setState({ term: event.target.value})
console.log(event.target.value);
}

fetchData(){
  var url = 'https://reqres.in/api/users'
  fetch(url)
      .then(res=>res.json())
      .then(json=>this.setState({students: json.data}))
}

componentWillMount(){
  this.fetchData()
}


 
   
   render() {
     const{term, students} = this.state;
       return (
       
      <header className="masthead">
    <div className="container">
      <div className="intro-text">
        <div className="intro-lead-in">Welcome To Our Market!</div>
        <div className="intro-heading text-uppercase">It's Nice To Meet You</div>
      </div>
    </div>
  </header>
  
 


       )
   }
 
}
