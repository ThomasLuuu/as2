import React,{Component}   from 'react'
import Pagination from "react-js-pagination"

//validation starts from here
function FormError(props) {
    if (props.isHidden) {return null;}
    return (
      <div className="form-warning">
          {props.errorMessage}
      </div>
    )
  }
  const pannelFooter = {
    float: 'right',

    color: 'black',
    padding: '8px 16px',
    
}
  const validateInput = (checkingText) => {
    
    const regexp = /^\d{10,11}$/; 
    // regular expression - checking if phone number contains only 10 - 11 numbers
    
    if (regexp.exec(checkingText) !== null) {
            return {
                isInputValid: true,
                errorMessage: ''
            };
        } else {
            return {
                isInputValid: false,
                errorMessage: 'Số điện thoại phải có 10 - 11 chữ số.'
            };
        }
}




function searchingFor(term){
  return function (x) {
    return x.name.toLowerCase().includes(term.toLowerCase()) || false;
  }
} 

const url =  'http://13.251.156.195:8080/products'
export default class DetailProduct extends React.Component {
 
   constructor(props) {
       super(props)
       this.state = {
           students: [],
           term : "",
           id: '',
           name: '',
           addNew: true,
           username: '',
           activePage: 1,
           itemPerPage:4,
           price:'',
           description:'',
           imageURL:''
       }
       this.handlePageChange = this.handlePageChange.bind(this);

       this.searchHandeler= this.searchHandeler.bind(this);

       
   }
   handleUsernameChange (e)  {
    console.log('handleUsernameChange()');
    this.setState({
      username: e.target.value
    });
  }

  handlePageChange(pageNumber) {
    this.setState({ activePage: pageNumber });
}

   projectDetails(item, index) {
        console.log(index);
    }
    projectDetails(item, index) {
        console.log(index);
    }
  handleSubmit(e ) {
    console.log('handleSubmit() Submit form with state:', this.state);
    e.preventDefault();
  }
 
   searchHandeler(event){
    this.setState({ term: event.target.value})
    console.log(event.target.value);
    }
    
   fetchData() {
     
       fetch(url)
           .then(res => res.json())
           .then(json=>{
            
            var list = json.filter(s=>typeof s.id!=='undefined' && s.id!=="" && s.id.includes("s3") && s.imageURL!=="")
            this.setState({students: list})})

   }
 
   componentDidMount() {
       this.fetchData()
   }
 setSize(){
    this.setState({
        isMax:!this.state.isMax
    });             
    if(!this.state.isMax){
        //clear style for jquery animate;
        $(this.refs.selfdiv).attr("style",null);
        setTimeout(()=>{        
            $(this.refs.selfdiv).animate({
                  top:'0px',
                  right: '0px',
                  bottom: '0px',
                  left: '0px'
            },500);     
        },100); 
    }
    console.log(this.props.children);
    if(this.props.children[1].props['data-event']){
        var self=this;
        setTimeout(()=>{
            self.props.children[1].props['data-event'].call();  
        },700);         
    }
}
   handleChange(e) {
       var obj = {}
       obj[e.target.name] = e.target.value
       this.setState(obj)
   }
 
   save() {
       if(this.state.addNew === true){
           fetch(url, {
               method: 'post',
               headers: {
                   'Content-Type': 'application/json',
                   'Accept': 'application/json'
               },
               body: JSON.stringify({ id: this.state.id, name: this.state.name, description: this.state.description, price: this.state.price, imageURL: this.state.imageURL })
           }).then(res => res.json())
               .then(json => this.fetchData())
       }
       else{
           fetch(url, {
               method: 'put',
               headers: {
                   'Content-Type': 'application/json',
                   'Accept': 'application/json'
               },
               body: JSON.stringify({ id: this.state.id, name: this.state.name, price: this.state.price, description: this.state.description, imageURL: this.state.imageURL })
           }).then(res => res.json())
               .then(json => this.fetchData())
       }
      
   }
 
   delete(id){
       if(confirm('Do you want to delete?')){
           fetch(url + "/"+id, {
               method: 'delete',
           }).then(res=>res.json())
           .then(json=>this.fetchData())
       }
    
   }
 
   add(id, name, price, description,imageURL){
       this.setState({id: '', name: '',price: '', description:'',imageURL:'', addNew: true})
   }
 
   edit(id, name,price,description,imageURL){
       this.setState({id: id, name: name, price: price, description: description, imageURL: imageURL, addNew: false})
       
   }

   render() {
    const{term, students} = this.state;
    var indexOfLast = this.state.activePage * this.state.itemPerPage;
    var indexOfFirst = indexOfLast - this.state.itemPerPage;
    var listItems = this.state.students.filter(searchingFor(term)).slice(indexOfFirst,indexOfLast).map(s=>
       <div className="row">
           <div className="col-md-2 img-card">
                <img src= {s.imageURL} />
           </div>
           <div className="col-md-2">
                {s.name}
           </div>
           <div className="col-md-2">
                {s.description}
           </div>
           <div className="col-md-2">
                {s.price}
           </div>
           <div className="col-md-2">
           <a className="btn btn-primary btn-xl text-uppercase js-scroll-trigger" onClick={this.delete.bind(this, s.id)}>Delete</a>

           </div>
           <div className="col-md-2">
           <a className="btn btn-primary btn-xl text-uppercase js-scroll-trigger" onClick={this.edit.bind(this, s.id, s.name, s.price, s.description, s.imageURL)}>Edit</a>

           </div>
           
           

       </div>
        
                     
            

        
    );
       return (
           
           <div>

               

               <div className="container-flex editstyle" >
              
<div style={pannelFooter}>
                            <h3>
                                Pages display
                            </h3>
                        <Pagination
                            activePage={this.state.activePage}
                            itemsCountPerPage={3}
                            totalItemsCount={this.state.students.length}
                            pageRangeDisplayed={5}
                            onChange={this.handlePageChange.bind(this)}
                            className="Pagination"
                            
                        />
                        </div>
                        <div className="row">
                            <h4>
                                Searching and edit products or add new products
                            </h4>

                        </div>
                   <div className="row">
                       <div className="col-md-8">
                       <form>  
      <input className="form-control search-bar" type="text" onChange={this.searchHandeler} value={term}/>
      
      


</form>
                       <br/>
                        {listItems}
                        </div>
                        <div className="col-md-4">
                            <div className="container">
                        <h2>Edit/Add Products</h2>

                        
               Product's id: <input className="edit-change" type="text" id="id" name="id" value={this.state.id} onChange={this.handleChange.bind(this)} />
               <br />
 
               Product's name: <input className="edit-change" type="text" id="name" name="name" value={this.state.name}
                   onChange={this.handleChange.bind(this)}
               />
               <br/>
               Product's price: 
               <input className="edit-change" type="text" id="price" name="price" value={this.state.price} onChange={this.handleChange.bind(this)} />
               <br />
               Product's description: <input className="edit-change" type="text" id="description" name="description" value={this.state.description} onChange={this.handleChange.bind(this)} />
               <br />
               Product's picture: <input className="edit-change" type="text" id="imageURL" name="imageURL" value={this.state.imageURL} onChange={this.handleChange.bind(this)} />

               <button className="btn btn-primary" onClick={this.save.bind(this)}>Save</button>
               <button className="btn btn-primary" onClick={this.add.bind(this)}>Add new</button>
                        </div>
                        </div>
               
               </div>
               <div style={pannelFooter}>
                            <h3>
                                Pages display
                            </h3>
                        <Pagination
                            activePage={this.state.activePage}
                            itemsCountPerPage={3}
                            totalItemsCount={this.state.students.length}
                            pageRangeDisplayed={5}
                            onChange={this.handlePageChange.bind(this)}
                            className="Pagination"
                            
                        />
                    </div>
               </div>
 
              
                    <div>
                         <form onSubmit={this.handleSubmit}>
        <div className="form-group">
          <label htmlFor="username">Name</label>
          <input
            id="username"
            name="username" 
            value={this.state.username}
            onChange={this.handleUsernameChange.bind(this)}
            placeholder="Name"
            pattern="[A-Za-z]{3,10}"
            className="form-control" />
        </div>

        <button className="btn btn-primary">Submit</button>
      </form>
                    </div>
           </div>
       )
   }
 
}
 
