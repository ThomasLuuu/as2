import React,{Component}   from 'react'
import Pagination from "react-js-pagination"
import List from './List.jsx'
import {BrowserRouter as Router, Link, Route, Switch} from 'react-router-dom'
import DetailProduct from './DetailProduct.jsx'
import {withRouter} from 'react-router-dom'
import Edit from './Edit.jsx'
import Products from './Products.jsx'
function searchingFor(term){
  return function (x) {
    return x.name.toLowerCase().includes(term.toLowerCase()) || false;
  }
} 

function PriceSearch(pricecheck){
    
    return function(a){
        return  a.price > pricecheck || false;
    }
}
function PriceSearchMin(pricecheckmin){
    return function(b){
        return  pricecheckmin < b.price || false;
    }
}
const pannelFooter = {
    float: 'right',

    color: 'black',
    padding: '8px 16px',
    
}

const force ={
    display:'inline'
}

const active = {
    color :'yellow'

}
const passive ={
    color :'grey'
}
const pricestyle ={
    padding: '30px'
}

const url =  'http://13.251.156.195:8080/products'
export default class Grid extends React.Component {
 
   constructor(props) {
       super(props)
       this.state = {
           students: [],
           term : "",
           id: '',
           name: '',
           addNew: true,
           username: '',
           activePage: 1,
           itemPerPage:8,
           pricecheck: "",
           pricecheckmin:""
               }
       this.handlePageChange = this.handlePageChange.bind(this);

       this.searchHandeler= this.searchHandeler.bind(this);

       this.PriceHandeler=this.PriceHandeler.bind(this);

       this.PriceHandelerMin=this.PriceHandelerMin.bind(this);

       
   }

   handlePageChange(pageNumber) {
    this.setState({ activePage: pageNumber });
}

   projectDetails(item, index) {
        console.log(index);
    }
    projectDetails(item, index) {
        console.log(index);
    }
   searchHandeler(event){
    this.setState({ term: event.target.value})
    console.log(event.target.value);
    }

    PriceHandeler(event){
        this.setState({pricecheck: event.target.value})
        console.log(event.target.value);
    }

    PriceHandelerMin(event){
        this.setState({pricecheckmin: event.target.value})
        console.log(event.target.value);
    }

    
    
   fetchData() {
     
       fetch(url)
           .then(res => res.json())
           .then(json=>{
            
            var list = json.filter(s=>typeof s.id!=='undefined' && s.id!=="" && s.id.includes("s3") && s.imageURL!=="")
            this.setState({students: list})})

   }
 
   componentDidMount() {
       this.fetchData()
   }
   setSize(){
    this.setState({
        isMax:!this.state.isMax
    });             
    if(!this.state.isMax){
        //clear style for jquery animate;
        $(this.refs.selfdiv).attr("style",null);
        setTimeout(()=>{        
            $(this.refs.selfdiv).animate({
                  top:'0px',
                  right: '0px',
                  bottom: '0px',
                  left: '0px'
            },500);     
        },100); 
    }
    console.log(this.props.children);
    if(this.props.children[1].props['data-event']){
        var self=this;
        setTimeout(()=>{
            self.props.children[1].props['data-event'].call();  
        },700);         
    }
}
   handleChange(e) {
       var obj = {}
       obj[e.target.name] = e.target.value
       this.setState(obj)
   }
 
 
 

   render() {
            const{term, students,pricecheck, pricecheckmin} = this.state;
            var indexOfLast = this.state.activePage * this.state.itemPerPage;
            var indexOfFirst = indexOfLast - this.state.itemPerPage;
            var listItems = this.state.students.filter(searchingFor(term)).filter(PriceSearch(pricecheck)).filter(PriceSearchMin(pricecheckmin)).slice(indexOfFirst,indexOfLast).map(s=>  
                <div id="change" className= "col-md-12" >
                    <div className="card">
                        <a className="img-card">
                        <img  src={s.imageURL}/>


                        </a>
                        <br />
                        <div className="card-content">
                            <h4 className="card-title">
                                <a>
                                     
                                    Product name:  {s.name} 
                                 </a>
                            </h4>

                            <div>
                                 Price: {s.price} đ 
                             </div>
                            
                         </div>

                             <div className="card-read-more" >
                                 
                             
                                 <span className="fa fa-star" style={active}></span>
                                 <span className="fa fa-star" style={active}></span>
                                 <span className="fa fa-star" style={active}></span>
                                 <span className="fa fa-star" style={passive}></span>
                                 <span className="fa fa-star" style={passive}></span>
                                 
                                 <Router>

                                 <Link target="_blank"   className="nav-link" to={"/Edit"}>Detail Product </Link>
                             
                                    <Switch>
                                        <Route exact path="/Edit" component={Edit}></Route>


                                    </Switch>
      
  
 

                                </Router>
                             </div>
                             
                    

                
                </div>
                </div>
            );
            
       return (
           <div>
               <table>
               

               <div className="container-flex"  ref="selfdiv">
               <form>  
      <input className="form-control search-bar" type="text" onChange={this.searchHandeler} value={term} placeholder="search your product"/>
      <div className="row">
              <h4>
                  Filter products by lowest price and highest price!!
              </h4>


      </div>
      <div className="row" style={pricestyle}>
          
          <div className="col-md-6">
                <input type="text" onChange={this.PriceHandeler} value={pricecheck} placeholder="Type lowest price"/>

          </div>

          

          <div className="col-md-6">
                <input type="text" onChange={this.PriceHandelerMin} value={pricecheckmin} placeholder="Type highest price" />

          </div>
      </div>
      

      
      


</form>
                        <div style={pannelFooter}>
                            <h3>
                                Pages display
                            </h3>
                        <Pagination
                            activePage={this.state.activePage}
                            itemsCountPerPage={3}
                            totalItemsCount={this.state.students.length}
                            pageRangeDisplayed={5}
                            onChange={this.handlePageChange.bind(this)}
                            className="Pagination"
                            
                        />
                        </div>
                   <div className="row">
                       <br/>
                        {listItems}
               
               </div>
               <div style={pannelFooter}>
                            <h3>
                                Pages display
                            </h3>
                        <Pagination
                            activePage={this.state.activePage}
                            itemsCountPerPage={3}
                            totalItemsCount={this.state.students.length}
                            pageRangeDisplayed={5}
                            onChange={this.handlePageChange.bind(this)}
                            className="Pagination"
                            
                        />
                    </div>
               </div>
 
               </table>
           </div>
       )
   }
 
}