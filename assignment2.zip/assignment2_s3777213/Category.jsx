import React,{Component}   from 'react'
import Grid from './Grid.jsx'
import List from './List.jsx'
  



function searchingFor(term){
  return function (x) {
    return x.name.toLowerCase().includes(term.toLowerCase()) || false;
  }
} 
const changeview = {
  float: 'right',

  padding: '8px 16px',
  
}
const url =  'http://13.251.156.195:8080/products'
export default class Category extends React.Component {
 
   constructor(props) {
       super(props)
       this.state = {
           students: [],
           term : "",
           id: '',
           name: '',
           addNew: true,
           username: '',
           showGrid: true
       }
       this.searchHandeler= this.searchHandeler.bind(this);

       
   }

   toggle(){
    this.setState({showGrid: !this.state.showGrid})
}

   searchHandeler(event){
    this.setState({ term: event.target.value})
    console.log(event.target.value);
    }
    
   fetchData() {
     
       fetch(url)
           .then(res => res.json())
           .then(json=>{
            
            var list = json.filter(s=>typeof s.id!=='undefined' && s.id!=="" && s.id.includes("s3") && s.imageURL!=="")
            this.setState({students: list})})

   }
 
   componentDidMount() {
       this.fetchData()
   }
 
   handleChange(e) {
       var obj = {}
       obj[e.target.name] = e.target.value
       this.setState(obj)
   }
 
 
 

   render() {
            const{term, students} = this.state;

       return (
         <section className="category">
           <div>
                <h4 className="headercategory" >Products Category</h4>              
               

               <div className="container">
                   <div className="row">
                     <div className="col">
                     <button onClick={this.toggle.bind(this)}  id="curtainInput" className="fas fa-list btn-primary" style={changeview}  >

</button>
{this.state.showGrid? <Grid/>: <List/>}

                     </div>

                   </div>
              
               </div>
 
               
           </div>
           </section>

       )
   }

 
}
 
